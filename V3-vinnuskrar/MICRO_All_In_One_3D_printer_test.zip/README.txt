                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2975429
*MICRO* All In One 3D printer test by majda107 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Are you suffering from issue and can't find any way to fix it?!
Be sure to checkout guide specified to this model, <b>guide isn't complete yet (23.8.2018) but there are some cool tweaks you should definitelly know!</b>
https://3dnation504795197.wordpress.com/guide/
Here is link for those people, who wan't to support me, it won't cost you any money, only 5 seconds of your time. So If you want to support me (without any fees), go to the guide this way! <b>Thanks <3</b>
http://j.gs/Bm9U

After my latests variations of this model got really popular, I've decided to take it even further and make smaller, but more effective model.

!PRINT THIS WITHOUT SUPPORTS AND WITH HIGH INFILL!
- small tip : try printing this with thing walls enabled in your slicer so you can get better tolerance results!

This test contains : overhang test, bridging test, stringing test, sharp-corner test, tolerance test, and scale test (diameter test).

I've decided to take off all text because it was really badly printable, because of this you can now find "test markup" in model images above.

I hope that you'll like this design, don't forget to share your own 3D printout in "MADE" section!

As always, feel free to tip me :-).

# Print Settings

Printer: Anet AM8, modified
Rafts: No
Supports: No
Resolution: 0.05-0.2 lh
Infill: 30%